//
//  resule.swift
//  math quiz
//
//  Created by Jun on 2022-09-29.
//

import Foundation

struct Result{
    var yourQuestion: String
    var yourAnswer: String
    var rightOrWrong: String
}
