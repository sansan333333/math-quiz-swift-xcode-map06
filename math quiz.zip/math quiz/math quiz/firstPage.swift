//
//  firstPage.swift
//  math quiz
//
//  Created by Jun on 2022-09-28.
//

import UIKit

class firstPage: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
